# Bibliothèque L1 — application PWA

Application personnelle de bibliothèque universitaire pour le Semestre I de Licence Agropastorale.

Nom du dépôt GitHub conseillé : `bibliotheque-l1`

Description GitHub à copier :
`Bibliothèque universitaire personnelle — Semestre I Agropastorale. Gestion des UE, ECUE et documents PDF/TD/TP/exercices/examens, avec stockage local sur le téléphone.`

Fichiers à mettre à la racine du dépôt :
index.html
style.css
app.js
sw.js
manifest.webmanifest
icon.svg
README.md

Puis GitHub : Settings → Pages → Deploy from a branch → main → / (root) → Save.
