# Bibliothèque L1 — PWA réelle

Cette version est conçue pour être publiée sur GitHub Pages et installée sur un téléphone.

Fonctions :
- 6 UE et 12 ECUE du semestre I préchargés.
- navigation UE → ECUE → catégories.
- ajout/modification/suppression d'UE et d'ECUE.
- ajout et ouverture de vrais fichiers depuis le téléphone.
- fichiers conservés dans IndexedDB du navigateur, pas dans un serveur.
- recherche.
- sauvegarde/restauration de la structure en JSON.
- manifest PWA + service worker pour le fonctionnement hors connexion du cœur de l'application après première visite.

Important : le dépôt GitHub contient le code de l'application, pas tes PDF personnels. Les documents importés restent dans le stockage local du navigateur sur ton téléphone. Fais régulièrement une sauvegarde de tes fichiers importants ailleurs.
